module.exports = function strLoader (source){
    return source.replace(/move/g,this.query.replacement)
}

