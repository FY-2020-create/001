const path = require('path');

module.exports = {
  entry: './src/index.js',

  resolveLoader:{
    module:[
      'node_module',
      "./replace-loader"
    ]
  },
  module: {
    rules: [
        { 
            test: /\.js$/, 
            use: [{ 
                // 本地引用loader
                loader: "string",
                options: {
                  Regexp:'move',
                  replacement: 'MOVE'
              }
            }]
        }
    ]
},
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'index.js'  // 这里修改了输出的文件名，我们运行package.json中的脚本，就会发现dist目录下生成的文件变成了index.js
  }
};