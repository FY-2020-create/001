const balls = document.querySelectorAll('.ball')
const moveball = id =>balls[id].style.transform = 'translateX(100px)';
const movePromise = id => new Promise(resolve =>{moveball(id);
setTimeout(resolve,1000)});
// callback 用法的 demo
function move(){
    moveball(0);
    setTimeout(()=>{
    moveball(1);
    setTimeout(()=>{moveball(2)},1000)
    },1000)
    }
    
    // Promise 用法的 demo
    function Movepromise(){
    movePromise(0)
    .then(()=>movePromise(1))
    .then(()=>moveball(2));
    }
    
    // async/await 用法的 demo
    async function go() {
      await movePromise(0);
      await movePromise(1);
      await movePromise(2);
    }
    let a =document.querySelector('.bt1');
    a.addEventListener("click",move);
    let b =document.querySelector('.bt2');
    b.addEventListener("click",Movepromise);
    let c =document.querySelector('.bt3');
    c.addEventListener("click", go);