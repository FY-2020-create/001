const path = require('path');
module.exports = {
  mode: 'development',
  entry: './src/index.js',
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: '[name].js'  // 这里修改了输出的文件名，我们运行package.json中的脚本，就会发现dist目录下生成的文件变成了index.js
  },
  resolveLoader:{
    modules: ['node_modules', path.resolve(__dirname, 'src')],//modules和node_modules的s不要写掉了
  },
  module: {
    rules: [{ 
            test: /\.js$/, 
            use: [{ 
                loader: "replace-loader.js",
                options: {
                  Regexp:'move',
                  replacement: 'MOVE'
              }
            }]
        }]
 },
};